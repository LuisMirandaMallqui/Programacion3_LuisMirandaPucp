package pe.edu.pucp.transitsoft.modelo;

/**
 *
 * @author eric
 */
public enum EstadoCaptura {
    REGISTRADO, 
    PROCESADO
}
