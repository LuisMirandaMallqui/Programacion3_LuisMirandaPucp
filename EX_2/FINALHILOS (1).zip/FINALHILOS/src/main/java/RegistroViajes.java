/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

import java.util.List;
import java.util.LinkedList;

public class RegistroViajes {
    private final List<Viaje> listaViajes = new LinkedList<>();
    private boolean abierto = true;

    public synchronized void registrarViaje(Viaje viaje) {
        if (!abierto) {
            System.out.println("Estación cerrada. No se registró el viaje de " + viaje.getCliente());
            return;
        }
        listaViajes.add(viaje);
        System.out.println("Cliente " + viaje.getCliente() + " registró viaje a " +
                           viaje.getDestino() + " (" + viaje.getDuracionSegundos() + "s)");
        notifyAll();
    }

    public synchronized Viaje obtenerViaje() {
        while (listaViajes.isEmpty() && abierto) {
            try {
                wait();
            } catch (InterruptedException e) {
                return null;
            }
        }
        if (!listaViajes.isEmpty()) return listaViajes.remove(0);
        return null;
    }
    
    public void atenderViajes(String nombre) {
        while (estaAbiertaOConPendientes()) {
            Viaje viaje = obtenerViaje();
            if (viaje != null) {
                System.out.println(nombre + " inicia viaje de " + viaje.getCliente() +
                                   " a " + viaje.getDestino() + " (" + viaje.getDuracionSegundos() + "s)");
                try {
                    Thread.sleep(viaje.getDuracionSegundos() * 1000L);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
                System.out.println(nombre + " finalizó viaje de " + viaje.getCliente()
                        + " y le dió su lapaso por dibujo");
            }
        }
        System.out.println(nombre + " terminó su jornada.");
    }

    public synchronized void cerrarEstacion() {
        abierto = false;
        System.out.println("Estación cerrada.");
        notifyAll();
    }

    public synchronized boolean estaAbiertaOConPendientes() {
        return abierto || !listaViajes.isEmpty();
    }
}

