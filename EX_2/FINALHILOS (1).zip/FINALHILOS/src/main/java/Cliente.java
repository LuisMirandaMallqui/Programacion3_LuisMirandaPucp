/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


public class Cliente implements Runnable {
    private final String destino;
    private final int duracion;
    private final RegistroViajes registro;

    public Cliente(String destino, int duracion, RegistroViajes registro) {
        this.destino = destino;
        this.duracion = duracion;
        this.registro = registro;
    }

    @Override
    public void run() {
        String nombre = Thread.currentThread().getName();
        try {
            Thread.sleep((int)(Math.random() * 3000)); // Llega en cualquier momento
        } catch (InterruptedException e) {}
        registro.registrarViaje(new Viaje(nombre, destino, duracion));
    }
}

