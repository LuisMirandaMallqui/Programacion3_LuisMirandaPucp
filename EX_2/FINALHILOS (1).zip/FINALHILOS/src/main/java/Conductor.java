/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


public class Conductor implements Runnable {
    private final RegistroViajes registro;

    public Conductor(RegistroViajes registro) {
        this.registro = registro;
    }

    @Override
    public void run() {
        registro.atenderViajes(Thread.currentThread().getName());
    }
}

