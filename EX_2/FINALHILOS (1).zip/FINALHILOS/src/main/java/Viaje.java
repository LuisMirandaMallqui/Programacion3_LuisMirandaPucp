/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


/**
 *
 * @author User
 */
public class Viaje {
    private final String cliente;
    private final String destino;
    private final int duracionSegundos;

    public Viaje(String cliente, String destino, int duracionSegundos) {
        this.cliente = cliente;
        this.destino = destino;
        this.duracionSegundos = duracionSegundos;
    }

    public String getCliente() { return cliente; }
    public String getDestino() { return destino; }
    public int getDuracionSegundos() { return duracionSegundos; }
}
