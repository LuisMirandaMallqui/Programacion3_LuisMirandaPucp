/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

/**
 *
 * @author User
 */
public class EstacionTaxis {
    public static void main(String[] args) {
        RegistroViajes registro = new RegistroViajes();

        // Conductores
        Thread c1 = new Thread(new Conductor(registro), "Conductor 1");
        Thread c2 = new Thread(new Conductor(registro), "Conductor 2");
        Thread c3 = new Thread(new Conductor(registro), "Conductor 3");
        Thread c4 = new Thread(new Conductor(registro), "Conductor 4");
        Thread c5 = new Thread(new Conductor(registro), "Conductor 5");

        c1.start(); c2.start(); c3.start(); c4.start(); c5.start();

        // Clientes (nombre por hilo, no en bucle)
        Thread cl1 = new Thread(new Cliente("Irán", 4, registro), "Juan Zavala(RED PUFFLE)");
        Thread cl2 = new Thread(new Cliente("Plaza San Miguel", 5, registro), "Jerarquin");
        Thread cl3 = new Thread(new Cliente("DUBAI", 6, registro), "HOLASOYLARA");
        Thread cl4 = new Thread(new Cliente("PERLA NEGRA", 3, registro), "iackSparrow");
        Thread cl5 = new Thread(new Cliente("OFICINAS DEL DECANO", 7, registro), "Reclayerli");

        cl1.start(); cl2.start(); cl3.start(); cl4.start(); cl5.start();

        // Esperar antes de cerrar estación (10 segundos)
        try {
            Thread.sleep(10000);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }

        registro.cerrarEstacion();

        try {
            cl1.join(); cl2.join(); cl3.join(); cl4.join(); cl5.join();
            c1.join(); c2.join(); c3.join(); c4.join(); c5.join();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }

        System.out.println("Todos los hilos finalizaron correctamente.");
    }
}

