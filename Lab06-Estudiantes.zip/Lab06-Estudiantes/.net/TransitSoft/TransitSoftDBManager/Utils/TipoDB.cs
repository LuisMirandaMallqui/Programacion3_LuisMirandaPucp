﻿namespace PUCP.TransitSoft.Db.Utils {
    public enum TipoDB {
        MSSQL,
        MySQL
    }
}
