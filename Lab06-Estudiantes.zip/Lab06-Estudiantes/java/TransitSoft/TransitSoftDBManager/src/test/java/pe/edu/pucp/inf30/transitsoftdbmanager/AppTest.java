package pe.edu.pucp.inf30.transitsoftdbmanager;

import java.sql.Connection;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;
import pe.edu.pucp.transitsoft.db.DBManager;

/**
 * Unit test for simple App.
 */
public class AppTest {

    /**
     * Rigorous Test :-)
     */
    @Test
    public void shouldAnswerWithTrue() {
        Connection conexion = DBManager.getInstance().getConnection();
        assertNotNull(conexion);
    }
}
