package pe.edu.pucp.transitsoft.daoimpl.util;

public enum TipoOperacion {
    INSERTAR, ELIMINAR, ACTUALIZAR
}
