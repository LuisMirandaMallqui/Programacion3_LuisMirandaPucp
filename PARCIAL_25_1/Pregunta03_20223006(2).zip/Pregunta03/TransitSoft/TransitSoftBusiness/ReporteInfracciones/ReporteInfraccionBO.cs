﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
using TransitSoftDomain;
using TransitSoftPersistance.RegistroInfracciones.DAO;
using TransitSoftPersistance.RegistroInfracciones.Impl;

namespace TransitSoftBusiness.ReporteInfracciones
{
    public class ReporteInfraccionBO
    {
        private ReporteInfraccionDAO daoReporte;

        public ReporteInfraccionBO()
        {
            daoReporte = new ReporteInfraccionImpl();
        }

        public int insertar(ReporteInfraccion reporte)
        {
            int resultado = 0;

            daoReporte.insertar(reporte);

            return resultado;
        }
    }
}
