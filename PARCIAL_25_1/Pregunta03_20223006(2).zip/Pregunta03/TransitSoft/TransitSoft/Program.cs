﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using TransitSoftBusiness.ReporteInfracciones;
using TransitSoftDomain;

namespace TransitSoft
{
    public class Program
    {
        //Alessandro Salvador Sante Vega - 20223006
        public static void Main(string[] args)
        {
            ReporteInfraccionBO boReporte;
            boReporte = new ReporteInfraccionBO();
            BindingList<ReporteInfraccion> lista = new BindingList<ReporteInfraccion>();
            FileStream fs = new FileStream("reportes_infracciones.bin", FileMode.Open);
            BinaryFormatter formatter = new BinaryFormatter();
            try
            {
                while (fs.Position < fs.Length)
                {
                    ReporteInfraccion reporteInfr = (ReporteInfraccion)formatter.Deserialize(fs);
                    lista.Add(reporteInfr);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error al deserializar: " + ex.Message);
            }
            finally
            {
                fs.Close();
            }

            foreach(ReporteInfraccion report in lista){
                boReporte.insertar(report);
            }
        }
    }
}
