﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TransitSoftDBManager;
using TransitSoftDomain;
using TransitSoftPersistance.RegistroInfracciones.DAO;

namespace TransitSoftPersistance.RegistroInfracciones.Impl
{
    public class ReporteInfraccionImpl : ReporteInfraccionDAO
    {

        private MySqlConnection con;

        public int eliminar(int idReporte)
        {
            throw new NotImplementedException();
        }

        public int insertar(ReporteInfraccion reporte)
        {

            MySqlParameter[] parametros = new MySqlParameter[14];
            parametros[0] = new MySqlParameter("_REPORTE_ID", MySqlDbType.Int32);
            parametros[0].Direction = ParameterDirection.Output;
            parametros[1] = new MySqlParameter("_CONDUCTOR_ID", reporte.ConductorId);
            parametros[2] = new MySqlParameter("_PATERNO", reporte.Paterno);
            parametros[3] = new MySqlParameter("_MATERNO", reporte.Materno);
            parametros[4] = new MySqlParameter("_NOMBRES", reporte.Nombres);
            parametros[5] = new MySqlParameter("_VEHICULO_ID", reporte.VehiculoId);
            parametros[6] = new MySqlParameter("_PLACA", reporte.Placa);
            parametros[7] = new MySqlParameter("_MARCA", reporte.Marca);
            parametros[8] = new MySqlParameter("_MODELO", reporte.Modelo);
            parametros[9] = new MySqlParameter("_ANHO", reporte.Anho);
            parametros[10] = new MySqlParameter("_INFRACCION_ID", reporte.InfraccionId);
            parametros[11] = new MySqlParameter("_DESCRIPCION", reporte.Descripcion);
            parametros[12] = new MySqlParameter("_MONTO", reporte.Monto);
            parametros[13] = new MySqlParameter("_GRAVEDAD", reporte.Gravedad);
            DBManager.getInstance().EjecutarProcedimiento("INSERTAR_REGISTRO_INFRACCION", parametros);
            reporte.ReporteId = Int32.Parse(parametros[0].Value.ToString());

            return reporte.ReporteId;
        }

        public BindingList<ReporteInfraccion> listarTodos()
        {
            throw new NotImplementedException();
        }

        public int modificar(ReporteInfraccion reporte)
        {
            throw new NotImplementedException();
        }

        public ReporteInfraccion obtenerPorId(int idReporte)
        {
            throw new NotImplementedException();
        }
    }
}
