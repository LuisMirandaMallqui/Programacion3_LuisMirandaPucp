package pe.com.transitsoft.modelo;

/**
 *
 * @author eric
 */
public enum Gravedad {
    LEVE, 
    GRAVE, 
    MUY_GRAVE
}
