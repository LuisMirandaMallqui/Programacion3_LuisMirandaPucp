package pe.com.transitsoft.bo;

/**
 *
 * @author eric
 */
public enum TipoCampanha {
    SOLO_MUY_GRAVES, 
    GRAVES_Y_MUY_GRAVES, 
    MODO_GENERAL
}
