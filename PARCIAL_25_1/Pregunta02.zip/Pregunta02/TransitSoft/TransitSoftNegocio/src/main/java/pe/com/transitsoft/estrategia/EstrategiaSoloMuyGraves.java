package pe.com.transitsoft.estrategia;

import pe.com.transitsoft.dao.IConductorDAO;
import pe.com.transitsoft.daoimpl.ConductorDAOImpl;
import pe.com.transitsoft.modelo.Gravedad;

/**
 *
 * @author eric
 */
public class EstrategiaSoloMuyGraves extends EstrategiaCalculo {
    
    private final IConductorDAO conductorDAO;
    
    public EstrategiaSoloMuyGraves() {
        this.conductorDAO = new ConductorDAOImpl();
    }
    
    @Override
    public int calcularPuntos(int idConductor) {
        return conductorDAO.obtenerPuntos(idConductor, Gravedad.MUY_GRAVE);
    }
}
