package pe.com.transitsoft.bo;

/**
 *
 * @author eric
 */
public interface IConductorBO {
    int calcularPuntos(int idConductor, TipoCampanha campanha);
}
