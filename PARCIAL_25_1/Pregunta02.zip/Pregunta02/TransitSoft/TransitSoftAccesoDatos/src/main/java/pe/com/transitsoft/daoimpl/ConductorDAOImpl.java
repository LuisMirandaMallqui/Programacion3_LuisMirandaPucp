package pe.com.transitsoft.daoimpl;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import pe.com.transitsoft.config.DBManager;
import pe.com.transitsoft.dao.IConductorDAO;
import pe.com.transitsoft.modelo.Gravedad;

/**
 *
 * @author eric
 */
public class ConductorDAOImpl implements IConductorDAO {
    @Override
    public int obtenerPuntos(int idConductor, Gravedad gravedad) {
        try (
            Connection conn = DBManager.getInstance().getConnection();
            CallableStatement cmd = this.configurarComandoObtenerPuntos(conn, idConductor, gravedad);
        ) {
            cmd.executeQuery();
            
            return cmd.getInt("p_puntos");
        }
        catch (SQLException e) {
            System.err.println("Error SQL durante la busqeuda: " + e.getMessage());
            throw new RuntimeException("No se pudo encontrar el registro.", e);
        }
        catch (Exception e) {
            System.err.println("Error inpesperado: " + e.getMessage());
            throw new RuntimeException("Error inesperado al encontrar el registro.", e);
        }
    }
    
    private CallableStatement configurarComandoObtenerPuntos(
            Connection conn, int id, Gravedad gravedad) throws SQLException {
        String sql = "{CALL preg2_obtenerPuntosConductor(?, ?, ?)}";
        CallableStatement cmd = conn.prepareCall(sql);
        cmd.setInt("p_conductor_id", id);
        cmd.setString("p_gravedad", gravedad.name());
        cmd.registerOutParameter("p_puntos", Types.INTEGER);
        return cmd;
    }
}