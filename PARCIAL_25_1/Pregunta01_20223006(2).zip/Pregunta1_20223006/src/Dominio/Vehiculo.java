/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Dominio;

/**
 *
 * @author alulab14
 */
public class Vehiculo {
//        vehiculo1.setVehiculoId(1);
//        vehiculo1.setPlaca("ABC-123");
//        vehiculo1.setMarca("TOYOTA");
//        vehiculo1.setModelo("COROLLA");
//        vehiculo1.setAnho(2022);

    private int vehiculoId;
    private String placa;
    private String marca;
    private String modelo;
    private int anho;

    public int getVehiculoId() {
        return vehiculoId;
    }

    public void setVehiculoId(int vehiculoId) {
        this.vehiculoId = vehiculoId;
    }

    public String getPlaca() {
        return placa;
    }

    public void setPlaca(String placa) {
        this.placa = placa;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public int getAnho() {
        return anho;
    }

    public void setAnho(int anho) {
        this.anho = anho;
    }
    
    
}
