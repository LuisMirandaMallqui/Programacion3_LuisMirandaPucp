package Dominio;

/**
 *
 * @author eric
 */
public enum Gravedad {
    LEVE, 
    GRAVE, 
    MUY_GRAVE
}
