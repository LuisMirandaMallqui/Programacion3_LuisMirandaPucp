/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Dominio;

/**
 *
 * @author alulab14
 */
public class TipoLicencia {
    private int tipoLicenciaId;
    private String nombre;
    private String descripcion;

    public int getTipoLicenciaId() {
        return tipoLicenciaId;
    }

    public void setTipoLicenciaId(int tipoLicenciaId) {
        this.tipoLicenciaId = tipoLicenciaId;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }
    
    
}
