/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Strategy;

import Dominio.RegistroInfraccion;
import Dominio.VehiculoConductor;
import java.util.ArrayList;

/**
 *
 * @author alulab14
 */
public class Contexto {

    private Estrategia estrategia;
    private ArrayList<RegistroInfraccion> registros;
    private ArrayList<VehiculoConductor> vcs;

    public Contexto(Estrategia estrategia) {
        this.estrategia = estrategia;
    }

    public void ejecutarEstrategia(ArrayList<RegistroInfraccion> registros,
            ArrayList<VehiculoConductor>vcs) {
        estrategia.ejecutar(registros, vcs);
    }

    public void setEstrategia(Estrategia estrategia) {
        this.estrategia = estrategia;
    }
}
