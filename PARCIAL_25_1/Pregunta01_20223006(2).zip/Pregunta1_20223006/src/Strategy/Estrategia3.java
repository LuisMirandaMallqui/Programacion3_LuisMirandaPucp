/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Strategy;

import Dominio.Conductor;
import Dominio.RegistroInfraccion;
import Dominio.Vehiculo;
import Dominio.VehiculoConductor;
import java.util.ArrayList;

/**
 *
 * @author alulab14
 */
public class Estrategia3 implements Estrategia{

    @Override
    public void ejecutar(ArrayList<RegistroInfraccion> registroInfr, ArrayList<VehiculoConductor> vehicsConds) {
        Conductor conductor = new Conductor();
        Vehiculo vehiculo = new Vehiculo();
        for(RegistroInfraccion r : registroInfr){
            conductor = r.getConductor();
            vehiculo = r.getVehiculo();
            for(VehiculoConductor vc : vehicsConds){
                if(vc.getConductor() == conductor && vc.getVehiculo() == vehiculo){
                    if(r.getFecha().after(vc.getFechaAdquisicion())){
                        int puntosInfraccion = r.getInfraccion().getPuntos()/2;
                        int puntosActuales = conductor.getPuntosAcumulados();
                        conductor.setPuntosAcumulados(puntosActuales+puntosInfraccion);
                    }
                }
            }
        }
    }
    
}
