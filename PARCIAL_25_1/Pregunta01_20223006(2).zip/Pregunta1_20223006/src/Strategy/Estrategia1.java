/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Strategy;

import Dominio.Conductor;
import Dominio.Infraccion;
import Dominio.RegistroInfraccion;
import Dominio.VehiculoConductor;
import java.util.ArrayList;

/**
 *
 * @author alulab14
 */
public class Estrategia1 implements Estrategia{

    @Override
    public void ejecutar(ArrayList<RegistroInfraccion> registroInfr, ArrayList<VehiculoConductor> vehicsConds) {
        Conductor conductor = new Conductor();
        for(RegistroInfraccion r : registroInfr){
            conductor = r.getConductor();
            int puntosInfraccion = r.getInfraccion().getPuntos();
            int puntosActuales = conductor.getPuntosAcumulados();
            conductor.setPuntosAcumulados(puntosActuales+puntosInfraccion);
        }
        
    }

   
}
