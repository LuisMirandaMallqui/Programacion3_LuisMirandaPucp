package pe.edu.pucp.ex1.domain;

public class TipoLicencia {
    private int tipoLicenciaId;
    private String nombre;
    private String descripcion;
    
    public TipoLicencia(){}

    public int getTipoLicenciaId() {
        return tipoLicenciaId;
    }

    public void setTipoLicenciaId(int tipoLicenciaId) {
        this.tipoLicenciaId = tipoLicenciaId;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }
    
}
