package pe.edu.pucp.ex1.domain;

import java.util.Date;

public class VehiculoConductor {
    private Vehiculo vehiculo;
    private Conductor conductor;
    private Date fechaAdquisicion;
    
    public VehiculoConductor(){}

    public Vehiculo getVehiculo() {
        return vehiculo;
    }

    public void setVehiculo(Vehiculo vehiculo) {
        this.vehiculo = vehiculo;
    }

    public Conductor getConductor() {
        return conductor;
    }

    public void setConductor(Conductor conductor) {
        this.conductor = conductor;
    }

    public Date getFechaAdquisicion() {
        return fechaAdquisicion;
    }

    public void setFechaAdquisicion(Date fechaAdquisicion) {
        this.fechaAdquisicion = fechaAdquisicion;
    }
    
}
