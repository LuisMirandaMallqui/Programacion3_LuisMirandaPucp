package pe.edu.pucp.ex1.domain.enums;

public enum Gravedad {
    LEVE,
    GRAVE,
    MUY_GRAVE
}
