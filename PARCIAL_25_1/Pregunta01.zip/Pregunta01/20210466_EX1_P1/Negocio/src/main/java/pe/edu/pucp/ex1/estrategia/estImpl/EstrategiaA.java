package pe.edu.pucp.ex1.estrategia.estImpl;

import java.util.List;
import pe.edu.pucp.ex1.domain.RegistroInfraccion;
import pe.edu.pucp.ex1.domain.VehiculoConductor;
import pe.edu.pucp.ex1.estrategia.Estrategia;

public class EstrategiaA implements Estrategia {

    @Override
    public void ejecutar(List<RegistroInfraccion> ri, List<VehiculoConductor> vc) {
        for (RegistroInfraccion registroInfraccion : ri) {
            int pa = registroInfraccion.getConductor().getPuntosAcumulados();
            int p = registroInfraccion.getInfraccion().getPuntos();
            registroInfraccion.getConductor().setPuntosAcumulados(pa + p);
        }
    }
    
}
