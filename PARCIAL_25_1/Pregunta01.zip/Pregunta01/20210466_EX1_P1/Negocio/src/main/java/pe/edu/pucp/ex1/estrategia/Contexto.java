package pe.edu.pucp.ex1.estrategia;

import java.util.List;
import pe.edu.pucp.ex1.domain.RegistroInfraccion;
import pe.edu.pucp.ex1.domain.VehiculoConductor;

public class Contexto {
    private Estrategia estrategia;
    
    public Contexto(Estrategia estrategia){
        this.estrategia = estrategia;
    }
    
    public void ejecutarEstrategia(List<RegistroInfraccion> ri, List<VehiculoConductor> vc){
        estrategia.ejecutar(ri, vc);
    }
    
    public void setEstrategia(Estrategia estrategia){
        this.estrategia = estrategia;
    }
}
