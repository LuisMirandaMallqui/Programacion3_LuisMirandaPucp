package pe.edu.pucp.ex1.estrategia;

import java.util.List;
import pe.edu.pucp.ex1.domain.RegistroInfraccion;
import pe.edu.pucp.ex1.domain.VehiculoConductor;

public interface Estrategia {
    void ejecutar(List<RegistroInfraccion> ri, List<VehiculoConductor> vc);
}
