package pe.edu.pucp.ex1.estrategia.estImpl;

import java.util.Date;
import java.util.List;
import pe.edu.pucp.ex1.domain.RegistroInfraccion;
import pe.edu.pucp.ex1.domain.VehiculoConductor;
import pe.edu.pucp.ex1.estrategia.Estrategia;

public class EstrategiaB implements Estrategia{

    @Override
    public void ejecutar(List<RegistroInfraccion> ri, List<VehiculoConductor> vc) {
        for (RegistroInfraccion registroInfraccion : ri) {
            Date fecha = registroInfraccion.getFecha();
            int cid = registroInfraccion.getConductor().getConductorId();
            int vid = registroInfraccion.getVehiculo().getVehiculoId();
            for(VehiculoConductor vehiculoConductor : vc){
                if(cid == vehiculoConductor.getConductor().getConductorId() 
                        && vid == vehiculoConductor.getVehiculo().getVehiculoId() 
                        && fecha.getTime() > vehiculoConductor.getFechaAdquisicion().getTime()){
                    int pa = registroInfraccion.getConductor().getPuntosAcumulados();
                    int p = registroInfraccion.getInfraccion().getPuntos();
                    registroInfraccion.getConductor().setPuntosAcumulados(pa + p);
                }
            }
        }
    }
    
}
